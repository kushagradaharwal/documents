<?php
namespace Smj\Offersubscriber\Api;
interface Highlight
{
    /**
     * @api
     * @param \Smj\Offersubscriber\Api\Data\Highlight[] $highlightData
     * @return array
     */
    public function update(array $highlightData);
}