<?php
/**
 * @category   Smj
 * @package    Smj_Offersubscriber
 * @author     kushagra.daharwal@hotmail.com
 * @copyright LBVFASHION
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Smj\Offersubscriber\Model;

use Magento\Framework\Model\AbstractModel;

class Offersubscriber extends AbstractModel
{
    /**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init('Smj\Offersubscriber\Model\ResourceModel\Offersubscriber');
    }
}